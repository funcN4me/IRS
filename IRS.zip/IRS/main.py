import sys
sys.path.append('Interface/') 
sys.path.append('Windows/') 
sys.path.append('DataBase/')  
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import *

from main_window import MainWindow
from authenthication_window import AuthenticationWindow

def main():
    app = QtWidgets.QApplication(sys.argv)
    windowAuth = AuthenticationWindow()
    windowAuth.exec()

    if windowAuth.keys[0] == False:
        main_window = MainWindow()
        if windowAuth.keys[1] == True:
            main_window.AdminBtn.setVisible(True)
        main_window.show()
    else:
        exit(0)
    
    app.exec()

if __name__ =="__main__":
    main()