import sys
sys.path.append('Interface/')

from PyQt5 import QtWidgets
from PyQt5.QtWidgets import *

import admin_design, connection, data_base_commands

import re

class AdminWindow(QtWidgets.QDialog, admin_design.Ui_Dialog):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.InsertBtn.clicked.connect(self.insert_to_db)
        self.ShowAllInfoBtn.clicked.connect(self.show_all)
        self.RefreshList.clicked.connect(self.fill_admin_combobox)
        self.DeleteBtn.clicked.connect(self.delete)
        self.UpdateInfoBtn.clicked.connect(self.update_info)
        
        self.fill_admin_combobox()
    
        self.exit_trigger = False

    def update_info(self):
        row_count = self.InfoTable.rowCount()
        col_count = self.InfoTable.columnCount()
        
        df_list = 'update'
        for row in range(row_count):
            df_list2 = ''
            for col in range(col_count):
                table_item = self.InfoTable.item(row,col)
                df_list2 += ('' if table_item is None else str(table_item.text()))
            
            df_list += ' ' + df_list2
        
        # print(df_list)

        connection.query(df_list)
        self.fill_admin_combobox()


    def delete(self):
        a = ''
        FullName = self.FullNameComboBox.currentText()
        FullName = FullName.split(' ')
        fields = ['delete', FullName[0], FullName[1], FullName[2]]

        for i in fields:
            a += i + ' '
        # print(a)
        connection.query(a)
        self.fill_admin_combobox()


    def fill_admin_combobox(self):

        self.FullNameComboBox.clear()

        connection.query('load_admin_combobox')
        resp = connection.init_response()

        for i in range(len(resp)):
            resp[i] = re.sub('\(|\)|\'|,', '', resp[i])
        self.FullNameComboBox.addItems(resp)
        
    

    def insert_to_db(self):
        a = ''
        fields = ['insert', self.SurnameTextBox.text(), self.NameTextBox.text(), self.MiddlenameTextBox.text(), self.dateEdit.text(), self.PlaceOfBirthTextBox.text(), self.SerialNumberTextBox.text(), self.DatePasportTextBox.text(), self.PlaceOfIssueTextBox.text(), self.INNTextBox.text(), self.InsuranceNumberTextBox.text(), self.HomeAddressTextBox.text(), self.DegreeComboBox.currentText(), self.SpecialtyTextBox.text(), self.DepartmentTextBox.text(), self.PositionTextBox.text(), self.SalaryTextBox.text(), self.DateOfReceiptTextBox.text()]

        for i in fields:
            a += i + ' '
        connection.query(a)
        self.fill_admin_combobox()

    def show_all(self):
        self.InfoTable.clear()
        resp = data_base_commands.load_field(self.FullNameComboBox.currentText())

        
        self.InfoTable.setRowCount(17)
        self.InfoTable.setColumnCount(1)
        self.InfoTable.setHorizontalHeaderLabels(["Employee"])
        self.InfoTable.setVerticalHeaderLabels(["Surname", "Name", "Middlename", "Birthday", "City", "Serial Number", "Date of issue", "Place of issue", "INN number", "Insurance", "Home Address", "Degree", "Specialty", "Department", "Position", "Salary", "Date of receipt"])

        
        for i in range(len(resp)):
            self.InfoTable.setItem(i-1 , 0, QTableWidgetItem(re.sub('\(|\)|\'|,', '', resp[i])))
        
        self.InfoTable.setHorizontalHeaderLabels([re.sub('\(|\)|\'|,', '', resp[1])])


        self.InfoTable.resizeColumnsToContents()
    
    def closeEvent(self, event):
        self.exit_trigger = True
        # print("DAUN ESLI WIDESH ETO 1")
        event.accept()