from connection import *

def parse(field):
    if field == '':
        return '%'
    return field

def parseAdd(field):
    if field == '':
        return False
    return True

def load_field(field):
    query(field)
    resp = response()
    return resp
